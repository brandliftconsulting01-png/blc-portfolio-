import React from 'react';

// Single-file React component portfolio layout for Arkesh.R | BrandLift Consulting
// TailwindCSS classes are used for styling (no imports required here).
// Drop this file into a React app (Create React App / Vite) with Tailwind configured.

export default function ArkeshRPortfolio() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 antialiased">
      <header className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-indigo-500 to-pink-500 flex items-center justify-center text-white font-bold">AR</div>
            <div>
              <h1 className="text-xl font-semibold">Arkesh.R</h1>
              <p className="text-sm text-gray-500">Creative Digital Marketer • BrandLift Consulting</p>
            </div>
          </div>
          <nav className="hidden md:flex gap-6 text-sm">
            <a href="#work" className="hover:text-indigo-600">Work</a>
            <a href="#services" className="hover:text-indigo-600">Services</a>
            <a href="#approach" className="hover:text-indigo-600">Approach</a>
            <a href="#contact" className="hover:text-indigo-600">Contact</a>
          </nav>
        </div>
      </header>

      {/* HERO */}
      <section className="max-w-6xl mx-auto px-6 py-12 flex flex-col md:flex-row items-center gap-10">
        <div className="flex-1">
          <h2 className="text-3xl md:text-4xl font-extrabold leading-tight">I design beautiful brands & run ads that convert.</h2>
          <p className="mt-4 text-gray-600">Hi — I’m <strong>Arkesh.R</strong>, a digital marketer blending creative design and performance marketing. I build websites, logos, posters and high-performing Meta & Google campaigns that turn attention into revenue.</p>

          <ul className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <li className="bg-white p-4 rounded-lg shadow-sm">
              <strong>Web Designing</strong>
              <div className="text-sm text-gray-500">Responsive, SEO-friendly sites</div>
            </li>
            <li className="bg-white p-4 rounded-lg shadow-sm">
              <strong>Logo & Branding</strong>
              <div className="text-sm text-gray-500">Unique identities that convert</div>
            </li>
            <li className="bg-white p-4 rounded-lg shadow-sm">
              <strong>Poster & Creatives</strong>
              <div className="text-sm text-gray-500">Scroll-stopping visuals</div>
            </li>
            <li className="bg-white p-4 rounded-lg shadow-sm">
              <strong>Meta & Google Ads</strong>
              <div className="text-sm text-gray-500">Performance-first campaigns</div>
            </li>
          </ul>

          <div className="mt-6 flex items-center gap-3">
            <a href="#contact" className="inline-block bg-indigo-600 text-white px-5 py-2 rounded-lg shadow hover:bg-indigo-700">Hire me</a>
            <a href="#work" className="text-sm text-indigo-600 hover:underline">See my work</a>
          </div>
        </div>

        <div className="flex-1">
          <div className="w-full rounded-2xl overflow-hidden shadow-lg bg-gradient-to-br from-indigo-50 to-pink-50 p-6">
            <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=900&q=60" alt="hero" className="w-full h-64 object-cover rounded-lg" />
            <div className="mt-4">
              <h3 className="font-semibold">BrandLift Consulting</h3>
              <p className="text-sm text-gray-500">Design + Marketing solutions for startups & local businesses.</p>
            </div>
          </div>
        </div>
      </section>

      {/* WORK / PROJECTS */}
      <section id="work" className="max-w-6xl mx-auto px-6 py-12">
        <h3 className="text-2xl font-bold">Selected Work</h3>
        <p className="text-gray-600 mt-2">Cases that show design thinking + measurable results.</p>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Project Card (repeat) */}
          {Array.from({ length: 6 }).map((_, i) => (
            <article key={i} className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="h-44 bg-gray-100 flex items-center justify-center">
                <span className="text-gray-300">Project Image {i + 1}</span>
              </div>
              <div className="p-4">
                <h4 className="font-semibold">Project Title {i + 1}</h4>
                <p className="text-sm text-gray-500 mt-2">Brief: Web design + ad campaign — improved conversions and brand visibility.</p>
                <div className="mt-3 flex items-center justify-between text-sm">
                  <span className="text-gray-600">Role: Design + Ads</span>
                  <a href="#" className="text-indigo-600 hover:underline">View case</a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="max-w-6xl mx-auto px-6 py-12 bg-white">
        <h3 className="text-2xl font-bold">Services</h3>
        <p className="text-gray-600 mt-2">End-to-end offerings for growing brands.</p>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 border rounded-lg">
            <h4 className="font-semibold">Web Designing</h4>
            <p className="text-sm text-gray-500 mt-2">Responsive sites built to convert visitors into customers.</p>
          </div>

          <div className="p-6 border rounded-lg">
            <h4 className="font-semibold">Logo & Branding</h4>
            <p className="text-sm text-gray-500 mt-2">Identity systems that communicate your values clearly.</p>
          </div>

          <div className="p-6 border rounded-lg">
            <h4 className="font-semibold">Posters & Social Creatives</h4>
            <p className="text-sm text-gray-500 mt-2">High-engagement creatives for campaigns and launches.</p>
          </div>

          <div className="p-6 border rounded-lg">
            <h4 className="font-semibold">Meta & Google Campaigns</h4>
            <p className="text-sm text-gray-500 mt-2">Targeted, ROI-driven ad strategies with continuous optimization.</p>
          </div>

          <div className="p-6 border rounded-lg">
            <h4 className="font-semibold">Social Media Management</h4>
            <p className="text-sm text-gray-500 mt-2">Content strategy, posting calendar, and community engagement.</p>
          </div>

          <div className="p-6 border rounded-lg">
            <h4 className="font-semibold">Brand Consultation</h4>
            <p className="text-sm text-gray-500 mt-2">Workshops and strategy sessions to align brand & marketing goals.</p>
          </div>
        </div>
      </section>

      {/* APPROACH */}
      <section id="approach" className="max-w-6xl mx-auto px-6 py-12">
        <h3 className="text-2xl font-bold">My Approach</h3>
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h4 className="font-semibold">1. Discover</h4>
            <p className="text-sm text-gray-500 mt-2">Understand brand, audience, and goals through research.</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h4 className="font-semibold">2. Design</h4>
            <p className="text-sm text-gray-500 mt-2">Create visual systems and UX that reflect the brand voice.</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h4 className="font-semibold">3. Deliver</h4>
            <p className="text-sm text-gray-500 mt-2">Launch campaigns, measure results, and optimize for growth.</p>
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <footer id="contact" className="max-w-6xl mx-auto px-6 py-12 bg-gradient-to-r from-indigo-50 to-pink-50 rounded-tl-3xl rounded-tr-3xl mt-8">
        <div className="md:flex md:items-center md:justify-between">
          <div>
            <h3 className="text-2xl font-bold">Work with me</h3>
            <p className="text-gray-700 mt-2">I help brands grow through design + performance marketing. Let’s build something great together.</p>

            <div className="mt-4 text-sm text-gray-600">
              <div><strong>Email:</strong> brandliftconsulting01@gmail.com</div>
              <div className="mt-1"><strong>Phone:</strong> +91 8675923827</div>
              <div className="mt-1"><strong>Location:</strong> India (remote clients welcome)</div>
            </div>

            <div className="mt-6 flex gap-3">
              <a href="mailto:brandliftconsulting01@gmail.com" className="inline-block bg-indigo-600 text-white px-4 py-2 rounded-lg">Email Me</a>
              <a href="#work" className="inline-block border border-indigo-600 px-4 py-2 rounded-lg text-indigo-600">See Work</a>
            </div>
          </div>

          <div className="mt-8 md:mt-0">
            <div className="bg-white p-6 rounded-lg shadow-sm w-full max-w-md">
              <form>
                <label className="block text-sm font-medium">Your name</label>
                <input className="mt-2 p-2 block w-full rounded-md border" placeholder="Name" />

                <label className="block text-sm font-medium mt-4">Email</label>
                <input className="mt-2 p-2 block w-full rounded-md border" placeholder="Email" />

                <label className="block text-sm font-medium mt-4">Project brief</label>
                <textarea className="mt-2 p-2 block w-full rounded-md border" placeholder="Tell me about your project" rows={4} />

                <div className="mt-4 flex justify-end">
                  <button type="button" className="bg-indigo-600 text-white px-4 py-2 rounded-md">Send</button>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center text-sm text-gray-500">© {new Date().getFullYear()} Arkesh.R • BrandLift Consulting</div>
      </footer>
    </div>
  );
}
